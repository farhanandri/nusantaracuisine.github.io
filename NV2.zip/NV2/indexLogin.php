<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Nusantara Cuisine</title>
    <!--Ini adalah Menu Sesudah Login-->
</head>
<body>
    <header>
        <a href="indexLogin.php" class="logo">Nusantara<br>Cuisine<span>.</span></a>
        <ul class="navigation">
            <li><a href="#home">Utama</a></li>
            <li><a href="#about">Tentang</a></li>
            <li><a href="#recipe">Resep</a></li>
            <li><a href="#creators">Pembuat</a></li>
            <li><a href="index.html">Logout</a></li>
        </ul>
    </header>

    <menu class="home" id="home">
        <div class="content">
            <h2>Mudah dan Enak</h2>
            <P>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Necessitatibus consectetur veritatis nostrum eum, nemo distinctio. Dignissimos autem velit dolorum? Numquam architecto facere vitae porro odit unde corporis accusamus est sunt.</P>
        </div>
    </menu>

    <menu class="about" id="about">
        <div class="row">
            <div class="aboutText">
                <h2 class="titleText"><span>T</span>entang Kami</h2>
                <p>
                    Lorem ipsum dolor sit, amet consectetur adipisicing elit. A voluptatem facilis omnis sunt hic rem impedit, optio, quas ad numquam odit. Aspernatur accusantium nemo placeat natus, repellat reprehenderit. Mollitia, rerum!
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Deleniti ea labore inventore accusantium quod at asperiores vel impedit nam, enim assumenda rem non magni, quis tempora consectetur provident? Beatae, ipsum. Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum nam cumque, vero modi architecto explicabo, rem magnam optio ipsa quasi alias ratione deserunt velit dolores esse porro ex voluptatibus fugiat! Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima eius aliquid quam possimus qui laudantium molestias architecto quod. Alias sapiente voluptas nulla dolor expedita velit at repellendus, pariatur excepturi quos?Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quisquam voluptatum maxime quae tenetur ab tempore obcaecati rem veritatis odit, voluptates eius tempora, excepturi nobis dolorem ex, eligendi blanditiis sint nihil!Loremlorem
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi officiis a dolorem sint magnam. Suscipit eos itaque delectus, neque eaque, nemo nostrum optio nam illum laudantium consectetur nulla tenetur dolore! Lorem, ipsum dolor sit amet consectetur adipisicing elit. Assumenda aspernatur doloremque, voluptate blanditiis maiores porro eius nam autem reprehenderit ea neque placeat. Quasi excepturi amet nisi quisquam ullam deserunt minima. Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusamus consequuntur aspernatur voluptatem molestiae itaque cum incidunt voluptatibus delectus, provident maiores facere aperiam commodi, illum quas fugiat rerum cupiditate, consectetur laborum? Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi at eos quasi tempore voluptas ipsa laborum deserunt rem possimus id in, incidunt accusamus. Eaque vel pariatur molestias voluptas consequuntur praesentium.
                </p>
            </div>
            <div class="aboutText">
                <div class="imgBx">
                    <img src="img/aboutUs.jpg" alt="">
                </div>
            </div>
        </div>
    </menu>

    <menu class="recipe" id="recipe">
        <div class="title">
            <h2 class="titleText">Macam-Macam <span>R</span>esep</h2>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vel quod similique laboriosam possimus impedit debitis excepturi aliquid consequatur pariatur quasi, iste facilis maxime incidunt eaque voluptatem quis sed fuga saepe.</p>
        </div>

        <div class="content">
            <div class="box">
                <div class="imgBx">
                    <a href="detailNasiGoreng.html">
                    <img src="img/recipe1.jpg" alt="Foto Nasi Goreng"></a>
                </div>
                <div class="text">
                    <h3>Nasi Goreng</h3>
                </div>
            </div>

            <div class="box">
                <div class="imgBx">
                    <a href="detailGudeg.html">
                    <img src="img/recipe2.jpg" alt="Foto Gudeg"></a>
                </div>
                <div class="text">
                    <h3>Gudeg</h3>
                </div>
            </div>

            <div class="box">
                <div class="imgBx">
                    <a href="detailSotoBanjar.html">
                    <img src="img/recipe3.png" alt="Soto Banjar"></a>
                </div>
                <div class="text">
                    <h3>Soto Banjar</h3>
                </div>
            </div>

            <div class="title">
                <a href="listResepLogin.html" class="btn">Lihat Semua</a>
            </div>
        </div>
    </menu>

        <menu class="creators" id="creators">
        <div class="title black">
            <h2 class="titleText">Pembuat <span>N</span>usantara Cuisine</h2>
        </div>
        <div class="content">
            <div class="box">
                <div class="imgBx">
                    <img src="img/profilePicture.png">
            </div>
            <div class="text">
                <h3>Achmad Rafiq</h3>
            </div>
        </div>
            <div class="box">
                <div class="imgBx">
                    <img src="img/profilePicture.png">
            </div>
            <div class="text">
                <h3>Farhan Andrianca Sany</h3>
            </div>
        </div>
            <div class="box">
                <div class="imgBx">
                    <img src="img/profilePicture.png">
            </div>
            <div class="text">
                <h3>Habib Saputra</h3>
            </div>
        </div>
        </div>
    </menu>

    <div class="madeByText">
        <p>Made By <span>C6</span> Team.</p>
    </div>

    <script type="text/javascript" src="scroll.js"></script>

</body>
</html>